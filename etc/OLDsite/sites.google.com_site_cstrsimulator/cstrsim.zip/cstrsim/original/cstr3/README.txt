Additionally this version extends the syntax to permit change in the
setpoints of the reactor level and temperature (SP1, SP2)

Last option is 'Dynamically change controller setpoints?'
If answered YES, enter number of changes for each controller setpoint
and the pairs [Time instant, new setpoint value], see examples
