original: The original simulator written in Fortran
new: The reimplementation in C with many conceptual improvements