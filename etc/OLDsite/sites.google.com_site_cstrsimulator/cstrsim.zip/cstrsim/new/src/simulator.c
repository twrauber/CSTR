//CSTR Simulator

#include <stdio.h>
#include <stdlib.h>
#include "cstrsim.h"


int main(int argc, char *argv[]){

	printf("\n\n");
	printf("****************************************\n");
	printf("************ CSTR Simulator ************\n");
	printf("****************************************\n");
	
	procQuim(argc, argv);

	return 0;
}
