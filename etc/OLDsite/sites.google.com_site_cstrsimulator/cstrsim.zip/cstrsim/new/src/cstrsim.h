
//void volume(double x, double y[], double dydx[]);
int procQuim(int argc, char *argv[]);
