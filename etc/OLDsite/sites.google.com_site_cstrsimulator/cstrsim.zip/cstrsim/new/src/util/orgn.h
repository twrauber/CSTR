
int procQuimOrgn(int argc, char *argv[]);