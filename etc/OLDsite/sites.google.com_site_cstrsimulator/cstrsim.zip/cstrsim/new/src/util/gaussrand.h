
//double gaussrand(void);
double gauss_rand (void);
void insereRuido(double *q, double *h, double *r, double *c, double *cnt, double *ms, double *sdev, double *cnst, double *out);
