
void faultHandler(int it, int *fl, double *inst, double *nv, double *tau, double *initVal, double *ms, double *newVal);
void initSensorFaults(double *h, double *q, double *t, double *c, double *cnt, double *ms, double *initVal);