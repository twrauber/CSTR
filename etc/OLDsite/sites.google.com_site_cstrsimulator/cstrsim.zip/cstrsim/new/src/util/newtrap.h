
void newtRap(double *q, double *h, double *k, double mvalv, double *mvo, double ktb1,
    		 double mvalvc, int n);
