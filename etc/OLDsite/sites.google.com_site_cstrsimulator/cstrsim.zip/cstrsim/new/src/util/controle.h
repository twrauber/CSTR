
double ctrl(double e, double e_1, double e_2, double pre_out, double dt);
double slave_ctrl(double e, double e_1, double e_2, double pre_out, double dt);
double master_ctrl(double e, double e_1, double e_2, double pre_out, double dt);
