//CSTR Simulator

#include <stdio.h>
#include <stdlib.h>
#include "orgn.h"


int main(int argc, char *argv[]){

	printf("\n\n");
	printf("****************************************\n");
	printf("************ CSTR Simulator ************\n");
	printf("****************************************\n");
	
	procQuimOrgn(argc, argv);

	return 0;
}
