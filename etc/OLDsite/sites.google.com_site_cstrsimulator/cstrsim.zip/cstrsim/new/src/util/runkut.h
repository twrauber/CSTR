
int procQuimRK(int argc, char *argv[]);